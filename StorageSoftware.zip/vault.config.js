module.exports = {
    name: "Omer Šabić",
    // Auth system WIP
    username: "guestLogin",
    passowrd: "pwd1234"
}